import static org.junit.Assert.*;

/**
 * Created by test on 02-Mar-17.
 */
public class checkTest {
    @org.junit.Test
    public void checksm() throws Exception {

    }

    @org.junit.Test
    public void checkmed() throws Exception {

    }

    @org.junit.Test
    public void checklr() throws Exception {

    }

    @org.junit.Test
    public void checkel() throws Exception {

    }

}