/**
 * Created by test on 02-Mar-17.
 */
class mainTest extends groovy.util.GroovyTestCase {
    void setUp() {
        super.setUp()

    }

    void testMain() {

    }
}
